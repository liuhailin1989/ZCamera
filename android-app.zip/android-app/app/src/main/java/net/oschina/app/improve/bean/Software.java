package net.oschina.app.improve.bean;

/**
 * Created by fei on 2016/6/20.
 * desc:
 */
public class Software extends PrimaryBean {
    private String name;
    private String href;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getHref() {
        return href;
    }

    public void setHref(String href) {
        this.href = href;
    }

}

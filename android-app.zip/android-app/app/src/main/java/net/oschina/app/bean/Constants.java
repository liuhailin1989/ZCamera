package net.oschina.app.bean;

/**
 * 部分常量类
 */
public class Constants {
    public static final String INTENT_ACTION_USER_CHANGE = "net.oschina.action.USER_CHANGE";
    public static final String INTENT_ACTION_LOGOUT = "net.oschina.action.LOGOUT";
    public static final String WEICHAT_APPID = "wxa8213dc827399101";
    public static final String WEICHAT_SECRET = "5c716417ce72ff69d8cf0c43572c9284";
}

package net.oschina.app.improve.main.discover;

import net.oschina.app.improve.base.activities.BaseActivity;

/**
 * Created by haibin
 * on 2016/11/4.
 */

public class QRCodeActivity extends BaseActivity {
    @Override
    protected int getContentView() {
        return 0;
    }
}

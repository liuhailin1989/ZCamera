package net.oschina.app.improve.account.constants;

/**
 * Created by fei
 * on 2016/10/24.
 * desc:
 */

public interface UserConstants {

    String HOLD_ACCOUNT = "hold_account";
    String RETRIEVE_PWD_URL = "https://www.oschina.net/home/reset-pwd";

}

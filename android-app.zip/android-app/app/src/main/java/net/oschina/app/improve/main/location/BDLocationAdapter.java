package net.oschina.app.improve.main.location;

import com.baidu.location.BDLocation;
import com.baidu.location.BDLocationListener;

/**
 * Created by jzz
 * on 2017/2/8.
 * desc:
 */

public class BDLocationAdapter implements BDLocationListener {

    @Override
    public void onReceiveLocation(BDLocation bdLocation) {

    }
}

package net.oschina.app;

import android.app.Application;
import android.test.ApplicationTestCase;

/**
 * <a href="http://d.android.com/tools/testing/testing_android.html">Testing Fundamentals</a>
 */
public class OSCApplicationTest extends ApplicationTestCase<Application> {

    public OSCApplicationTest() {
        super(Application.class);
    }

    public void testParseUrl(){

    }

}